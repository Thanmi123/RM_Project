﻿using TeacherManagementModule.Entities;

namespace TeacherManagementModule.Repository
{
    public interface ITeacherRepository<T> where T : class
    {
        void AddTeacher(T entity);
        void UpdateTeacher(T entity);
        void DeleteTeacher(string teacherId);
        T GetTeacherById(string teacherId);
        List<T> GetTeachers();
        List<T> GetTeachersByClass(string teacherClass);
        List<T> GetTeachersBySubject(string teacherSubject);
    }
}
