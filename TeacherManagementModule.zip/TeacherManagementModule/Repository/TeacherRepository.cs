﻿using Microsoft.EntityFrameworkCore;
using TeacherManagementModule.Entities;
using TeacherManagementModule.Repository;

namespace TeacherManagementModule.Repository
{
    public class TeacherRepository : ITeacherRepository<Teacher>
    {
        private readonly MyContext _context;
        public TeacherRepository(MyContext context)
        {
            _context = context;
        }
        public void AddTeacher(Teacher entity)
        {
            try
            {
                _context.Teachers.Add(entity);
                _context.SaveChanges();
            }
            catch (Exception)
            {

                throw;
            }
        }

        public void DeleteTeacher(string teacherId)
        {
            try
            {
                Teacher teacher = _context.Teachers.Find(teacherId);
                _context.Teachers.Remove(teacher);
                _context.SaveChanges();
            }
            catch (Exception)
            {

                throw;
            }
        }

        public Teacher GetTeacherById(string teacherId)
        {
            try
            {
                return _context.Teachers.Find(teacherId);
            }
            catch (Exception)
            {

                throw;
            }
        }

        public List<Teacher> GetTeachers()
        {
            try
            {
                return _context.Teachers.ToList();
            }
            catch (Exception)
            {

                throw;
            }
        }

        public List<Teacher> GetTeachersByClass(string teacherClass)
        {
            try
            {
                return _context.Teachers.Where(x => x.teacherClass == teacherClass).ToList();
            }
            catch (Exception)
            {

                throw;
            }
        }

        public List<Teacher> GetTeachersBySubject(string teacherSubject)
        {
            try
            {
                return _context.Teachers.Where(x => x.teacherSubjectTaught == teacherSubject).ToList();
            }
            catch (Exception)
            {

                throw;
            }
        }

        public void UpdateTeacher(Teacher entity)
        {
            try
            {
                _context.Update(entity);
                _context.SaveChanges();
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
