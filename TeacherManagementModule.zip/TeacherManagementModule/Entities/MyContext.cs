﻿using Microsoft.EntityFrameworkCore;
namespace TeacherManagementModule.Entities
{
    public class MyContext:DbContext
    {

        private readonly IConfiguration configuration;

        public MyContext(IConfiguration configuration)
        {
            this.configuration = configuration;
        }

        //define entity set
        public DbSet<Teacher> Teachers { get; set; }
    
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            
            optionsBuilder.UseSqlServer(configuration.GetConnectionString("MyConnection"));
        }
    }
}
