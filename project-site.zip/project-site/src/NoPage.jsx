import React from 'react'

export default function NoPage() {
  return (
    <div>
      <h1>Nothig to see here </h1>
    </div>
  )
}
