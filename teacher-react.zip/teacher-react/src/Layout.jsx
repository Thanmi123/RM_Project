import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Home from './TeacherComponent/Home';
import TeacherProfile from './TeacherComponent/TeacherProfile';
import StudentPage from './TeacherComponent/StudentPage';
import MarkingComponent from './TeacherComponent/MarkingPage';

const TeacherManagement = () => {
  return (
    <Router>
      <div className="container mt-5">
        <h1 className="text-center mb-5">Teacher Management System</h1>
        <Switch>
          <Route path="/" exact component={Home} />
          <Route path="/profile" component={TeacherProfile} />
          <Route path="/students" component={StudentPage} />
          <Route path="/marking" component={MarkingComponent} />
        </Switch>
      </div>
    </Router>
  );
};

export default TeacherManagement;
