import logo from './logo.svg';
import './App.css';
import TeacherManagement from './Teacher';
import Home from './TeacherComponent/Home';
import TeacherProfile from './TeacherComponent/TeacherProfile';
import StudentPage from './TeacherComponent/StudentPage';
import MarkingPage from './TeacherComponent/MarkingPage';
import { BrowserRouter, Route, Routes } from 'react-router-dom';



function App() {
  return (
    <div className="App">
     {/* <TeacherManagement/> */}
     <BrowserRouter>
     <Routes>
      <Route index element={<Home/>}/>
      <Route path="TeacherProfile" element={<TeacherProfile/>}/>
      <Route path="StudentPage" element={<StudentPage/>}/>
      <Route path="MarkingPage" element={<MarkingPage/>}/>
     </Routes>
     </BrowserRouter>
     
    </div>
  );
}

export default App;
