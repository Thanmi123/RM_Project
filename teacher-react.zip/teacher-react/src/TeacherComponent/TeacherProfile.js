import React, { useState, useEffect } from 'react';
import axios from 'axios';

const TeacherProfile = () => {
  const [teacherProfile, setTeacherProfile] = useState(null);

  useEffect(() => {
    fetchTeacherProfile();
  }, []);

  const fetchTeacherProfile = () => {
    axios.get('http://localhost:5232/api/teacher/profile')
      .then(response => {
        setTeacherProfile(response.data);
      })
      .catch(error => {
        console.error('Error fetching teacher profile:', error);
      });
  };

  return (
    <div className="container mt-5">
      <h1>Teacher Profile</h1>
      {teacherProfile && (
        <div>
          <p>Name: {teacherProfile.name}</p>
          <p>Email: {teacherProfile.email}</p>
          <p>Subject Taught: {teacherProfile.subject}</p>
          {/* Add more profile details as needed */}
        </div>
      )}
    </div>
  );
};

export default TeacherProfile;
