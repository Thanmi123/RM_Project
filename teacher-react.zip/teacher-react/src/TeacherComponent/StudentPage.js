import React, { useState, useEffect } from 'react';
import axios from 'axios';

const StudentPage = () => {
  const [students, setStudents] = useState([]);

  useEffect(() => {
    fetchStudents();
  }, []);

  const fetchStudents = () => {
    axios.get('http://localhost:5232/api/students')
      .then(response => {
        setStudents(response.data);
      })
      .catch(error => {
        console.error('Error fetching students:', error);
      });
  };

  return (
    <div className="container mt-5">
      <h1>Students</h1>
      <ul>
        {students.map(student => (
          <li key={student.id}>
            <p>Name: {student.name}</p>
            <p>Class: {student.class}</p>
            {/* Add more student details as needed */}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default StudentPage;
