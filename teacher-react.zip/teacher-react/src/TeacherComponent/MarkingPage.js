import React, { useState } from 'react';
import axios from 'axios';

const MarkingPage = () => {
  const [mark, setMark] = useState('');

  const handleMarkChange = (event) => {
    setMark(event.target.value);
  };

  const handleAddMark = () => {
    axios.post('http://localhost:5232/api/marks', { mark })
      .then(response => {
        console.log('Mark added successfully');
      })
      .catch(error => {
        console.error('Error adding mark:', error);
      });
  };

  return (
    <div className="container mt-5">
      <h1>Marking Component</h1>
      <div className="form-group">
        <label htmlFor="mark">Enter Mark:</label>
        <input type="text" className="form-control" id="mark" value={mark} onChange={handleMarkChange} />
      </div>
      <button className="btn btn-primary" onClick={handleAddMark}>Add Mark</button>
    </div>
  );
};

export default MarkingPage;
