import React from 'react';
import { Link,Outlet } from 'react-router-dom';

const Home = () => {
  return (
    <div className="container mt-5">
      <div className="row"/>
        {/* <div className="col-md-6">
          <h1>Welcome to Our Website</h1>
          <p>
            We are dedicated to providing the best services and products to our customers.
          </p>
          <p>
            Explore our website to learn more about what we offer and how we can help you.
          </p>
          <button className="btn btn-primary">Learn More</button>
        </div> 
        <div className="col-md-6">
          <img src="/images/home-image.jpg" className="img-fluid" alt="Welcome" />
        </div>
      </div>*/}
      <div className="row mt-5">
        <div className="col-md-4">
          {/* <h2>TeacherProfile</h2> */}
          {/* <p>
            Learn more about our company and our mission.
          </p> */}
          <button className="btn btn-outline-primary"><Link to="/TeacherProfile"/>TeacherProfile</button>
        </div>
        <div className="col-md-4">
          {/* <h2>Our Products</h2>
          <p>
            Check out our wide range of products and services.
          </p>
          <button className="btn btn-outline-primary">View Products</button>
        </div>
        <div className="col-md-4">
          <h2>Contact Us</h2>
          <p>
            Have questions or need assistance? Contact us today.
          </p> */}
          <button className="btn btn-outline-primary"><Link to="/StudentPage"/>StudentPage</button>
        </div>
        <div className="col-md-4">
            <button className="btn btn-outline-primary"><Link to="/MarkingPage"/>MarkingPage</button>
        </div>
      </div>
      <main>
        <Outlet/>
      </main>
      
        <footer class="footer mt-auto py-3 text-dark">
  <div class="container">
    <div class="row">
      <div class="col-md-4">
        
        <p>Vero, tempor morbi, adipiscing aliqua nonummy proident perferendis? Laboris lacus quidem repellendus quasi.</p>
      </div>
      <div class="col-md-4">
        <h5>Quick Links</h5>
        <ul class="list-unstyled">
          <li><a href="#">About us</a></li>
          <li><a href="#">Careers</a></li>
          <li><a href="#">News & Articles</a></li>
          <li><a href="#">Legal Notice</a></li>
          <li><a href="#">Support</a></li>
        </ul>
      </div>
      <div class="col-md-4">
        <h5>Contact Us</h5>
        <ul class="list-unstyled">
          <li><a href="#">Help Center</a></li>
          <li><a href="#">Contact Us</a></li>
          <li><a href="#">Payment Center</a></li>
          <li><a href="#">Parent Community</a></li>
          <li><a href="#">School Hours</a></li>
        </ul>
        <p>8 AM - 5 PM, Monday - Saturday</p>
        <p>Aut, quae convallis minim cum ornare! Pede dictum convallis.</p>
        <ul class="list-inline">
          <li class="list-inline-item"><a href="#"><i class="fab fa-facebook"></i></a></li>
          <li class="list-inline-item"><a href="#"><i class="fab fa-linkedin"></i></a></li>
          <li class="list-inline-item"><a href="#"><i class="fab fa-instagram"></i></a></li>
        </ul>
      </div>
    </div>
  </div>
</footer>

      
    </div>
  );
};

export default Home;
